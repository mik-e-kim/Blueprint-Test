# Description

The resource is used to initialize, format and mount the partition to a folder
access path.
