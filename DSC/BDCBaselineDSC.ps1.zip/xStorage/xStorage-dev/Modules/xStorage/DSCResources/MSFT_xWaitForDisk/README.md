# Description

This resource is used to wait for a disk to become available.
